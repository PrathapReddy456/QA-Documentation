package readingdata;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author 
 */
public class Driver 
{
   public static void main(String[] args) throws FileNotFoundException 
	{
      Scanner in = new Scanner(new File("data.txt"));
      
      while(in.hasNext())
      {
         String line = in.nextLine();
         String[] tokens = line.split(" ");
         int sum = 0;
         for(int i = 1; i < tokens.length; i++)
         {
            sum += Integer.parseInt(tokens[i]);
         }
         System.out.println("Name of student: " + tokens[0]);
         System.out.println("Number of exam scores: " + 
               (tokens.length - 1));
         System.out.printf("Average of exam scores: %5.2f", 
               ((double) (sum) / (tokens.length - 1)));
         System.out.println();
         System.out.println();
         
         in = new Scanner(new File("jobs.txt"));
         while(in.hasNext())
         {
            String jobID = in.nextLine();
            String jobTitle = in.nextLine();
            String[] skills = (in.nextLine()).split(" ");
            double rateOfPay = Double.parseDouble(in.nextLine());
            int hoursPerWeek = Integer.parseInt(in.nextLine());
            
            System.out.println("Job id: " + jobID);
            System.out.println("Job title: " + jobTitle);
            System.out.print("There are " + skills.length + 
               " skills required for this job: ");
            for(int i = 0; i < skills.length; i++)
            {
               System.out.print(skills[i] + " ");
            }
            System.out.println();
            System.out.printf("Weekly wages estimate: $%6.2f",
               rateOfPay * hoursPerWeek);
            System.out.println();
            System.out.println();
         }
      }
   }
}
