
import java.util.function.BiFunction;
import java.util.function.DoubleFunction;
import java.util.function.Function;
import java.util.function.IntFunction;

public class LambdaExpressions {

    public static void main(String[] args) {

        // Define a function int -> int
        IntFunction timesTwo = x -> x * 2;
        System.out.println(timesTwo.apply(5));

        // Define a function double -> double
        DoubleFunction<Double> third = x -> x / 3;
        System.out.println(third.apply(4.5));
        System.out.println();

        String stars = "**********";
        // Define a function int -> String
        IntFunction<String> getStars
                = n -> (1 <= n && n <= 10) ? stars.substring(0, n) : "nostarsforyou";
        System.out.println(getStars.apply(3));
        System.out.println(getStars.apply(10));
        System.out.println(getStars.apply(-2));
        System.out.println(getStars.apply(20));
        System.out.println();
        
        // Lambda expressions can include a block of code, which should be 
        // enclosed in parentheses.
        // Also note that Java will infer the return type.
        String dashes = "----------";
        IntFunction getDashes = n -> {
            if(n >= 1 && n <= 10) {
                return dashes.substring(0,n);
            } else {
                return "nodashesfor you";
            }
        }; // semicolon terminates the definition for getDashes
        System.out.println(getDashes.apply(3));
        System.out.println(getDashes.apply(10));
        System.out.println(getDashes.apply(-2));
        System.out.println(getDashes.apply(20));
        System.out.println();
        
        // Define a function String -> String
        Function<String, String> halfString = s -> s.substring(0, s.length() / 2);
        System.out.println(halfString.apply("computerscience"));
        System.out.println(halfString.apply("tenletters"));
    }

}
